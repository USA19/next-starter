import React from "react";

function user() {
  return <div>user</div>;
}

export default user;
