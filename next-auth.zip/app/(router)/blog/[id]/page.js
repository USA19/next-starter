import React from "react";

function Page() {
  return <div>Params</div>;
}

export default Page;
