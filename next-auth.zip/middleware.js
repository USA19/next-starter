import { withAuth } from "next-auth/middleware";

export default withAuth(
  // `withAuth` augments your `Request` with the user's token.
  function middleware(req) {},
  {
    callbacks: {
      authorized: ({ token }) => {
        const { user, token: accessToken } = token || {};

        return accessToken && user;
      },
    },
  }
);

export const config = { matcher: ["/", "/blog"] };
