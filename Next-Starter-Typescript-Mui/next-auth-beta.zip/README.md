This is a Fantacy App.

## Getting Started

First, install all the dependencies by typing the following command

```bash
npm install
```

and then run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`.
