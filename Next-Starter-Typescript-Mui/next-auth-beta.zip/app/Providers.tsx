"use client";
import { FC } from "react";

import { SessionProvider } from "next-auth/react";
import { ChildrenProps } from "./layout";
import { ThemeProvider } from "@mui/material";
import customTheme from "@/theme";

const Providers: FC<ChildrenProps> = ({ children }) => {
  return (
    <SessionProvider>
      <ThemeProvider theme={customTheme}>{children}</ThemeProvider>
    </SessionProvider>
  );
};

export default Providers;
