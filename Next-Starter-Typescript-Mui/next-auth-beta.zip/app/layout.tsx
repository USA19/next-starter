import { Inter } from "next/font/google";
import Providers from "./Providers";
import { FC, ReactNode } from "react";

export interface ChildrenProps {
  children: ReactNode;
}

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Fantacy App",
  description: "",
};

const RootLayout: FC<ChildrenProps> = ({ children }) => {
  return (
    <html lang="en">
      <Providers>
        <body className={inter.className}>{children}</body>
      </Providers>
    </html>
  );
};

export default RootLayout;
